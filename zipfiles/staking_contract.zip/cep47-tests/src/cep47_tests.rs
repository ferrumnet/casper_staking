use std::collections::BTreeMap;

use casper_engine_test_support::{
    ExecuteRequestBuilder, InMemoryWasmTestBuilder, WasmTestBuilder, DEFAULT_ACCOUNT_ADDR,
    DEFAULT_ACCOUNT_KEY, DEFAULT_RUN_GENESIS_REQUEST,
};
use casper_execution_engine::storage::global_state::in_memory::InMemoryGlobalState;
use casper_types::bytesrepr::{FromBytes, ToBytes};
use casper_types::{account::AccountHash, runtime_args, Key, U256};
use casper_types::{CLTyped, ContractHash, RuntimeArgs, URef, BLAKE2B_DIGEST_LENGTH};
use test_env::TestEnv;
use blake2::{
    digest::{Update, VariableOutput},
    VarBlake2b,
};

use crate::cep47_instance::{CEP47Instance, Meta, TokenId};

const NAME: &str = "staking";
const ADDRESS: &str = "9e7283533626d0c7d43fa9ca745af20d8dac7fc3bfe03cdfe50d523a2a0f498d";

const ERC20_WASM: &str = "erc20.wasm";
const STAKING_WASM: &str = "staking_contract.wasm";
const ERC20_CONTRACT_NAME: &str = "erc20_token_contract";
const STAKING_CONTRACT_HASH: &str = "staking_contract_hash";
const ALLOWANCES_SEED_UREF: &str = "allowances";

fn deploy() -> (TestEnv, CEP47Instance, AccountHash) {
    let env = TestEnv::new();
    let owner = env.next_user();
    let contract = CEP47Instance::new(
        &env,
        NAME,
        owner,
        NAME.to_string(),
        ADDRESS.to_string(),
        0,
        1000000,
        0,
        1000000,
        U256::from(100000i64),
    );
    (env, contract, owner)
}

#[test]
fn test_approve_and_stake() {
    let mut builder = InMemoryWasmTestBuilder::default();
    builder.run_genesis(&DEFAULT_RUN_GENESIS_REQUEST).commit();

    let erc20_runtime_args = runtime_args! {
        "name" => "FERRUM_ERC20".to_string(),
        "symbol" => "F_ERC20".to_string(),
        "total_supply" => U256::from(500000i64),
        "decimals" => 8u8,
    };

    let erc_20_install_request =
        ExecuteRequestBuilder::standard(*DEFAULT_ACCOUNT_ADDR, ERC20_WASM, erc20_runtime_args)
            .build();

    builder
        .exec(erc_20_install_request)
        .expect_success()
        .commit();

    let erc20_contract_hash = get_erc20_contract_hash(&builder);

    let mint_request = ExecuteRequestBuilder::contract_call_by_hash(
        *DEFAULT_ACCOUNT_ADDR,
        erc20_contract_hash,
        "mint",
        runtime_args! {},
    )
    .build();

    builder.exec(mint_request).expect_success().commit();

    let erc20_contract_key: Key = erc20_contract_hash.into();

    let balance = balance_dictionary(
        &builder,
        erc20_contract_key,
        Key::Account(*DEFAULT_ACCOUNT_ADDR),
    );
    assert_eq!(balance, U256::from(510000));

    let staking_contract_runtime_args = runtime_args! {
        "name" => "FerrumX".to_string(),
        "address" => "9e7283533626d0c7d43fa9ca745af20d8dac7fc3bfe03cdfe50d523a2a0f498d".to_string(),
        "staking_starts" => 0u64,
        "staking_ends" => 1755994649u64,
        "withdraw_starts" => 0u64,
        "withdraw_ends" => 1755994649u64,
        "staking_total" => U256::from(500000),
    };

    let staking_contract_install_request = ExecuteRequestBuilder::standard(
        *DEFAULT_ACCOUNT_ADDR,
        STAKING_WASM,
        staking_contract_runtime_args,
    )
    .build();

    builder
        .exec(staking_contract_install_request)
        .expect_success()
        .commit();

    let staking_contract_hash = get_stacking_contract_hash(&builder);

    let staking_contract_key: Key = staking_contract_hash.into();

    let approve_args = runtime_args! {
        "spender" => staking_contract_key,
        "amount" => U256::from(10),
    };

    let approve_request = ExecuteRequestBuilder::contract_call_by_hash(
        *DEFAULT_ACCOUNT_ADDR,
        erc20_contract_hash,
        "approve",
        approve_args,
    )
    .build();

    builder.exec(approve_request).expect_success().commit();

    let actual_allowance = allowance_dictionary(&builder,
        erc20_contract_key,
        Key::Account(*DEFAULT_ACCOUNT_ADDR),
        staking_contract_key
    );

    assert_eq!(actual_allowance, U256::from(10));

    let stake_args = runtime_args! {
        "amount" => U256::from(5),
    };


    let stake_request = ExecuteRequestBuilder::contract_call_by_hash(
        *DEFAULT_ACCOUNT_ADDR,
        staking_contract_hash,
        "stake",
        stake_args,
    )
    .build();

    builder.exec(stake_request).expect_success().commit();

}

/// Creates a dictionary item key for an (owner, spender) pair.
fn make_allowances_dictionary_item_key(owner: Key, spender: Key) -> String {
    let mut preimage = Vec::new();
    preimage.append(&mut owner.to_bytes().unwrap());
    preimage.append(&mut spender.to_bytes().unwrap());

    let key_bytes = create_blake2b_hash(&preimage);
    hex::encode(&key_bytes)
}

pub(crate) fn create_blake2b_hash<T: AsRef<[u8]>>(data: T) -> [u8; BLAKE2B_DIGEST_LENGTH] {
    let mut result = [0; BLAKE2B_DIGEST_LENGTH];
    // NOTE: Assumed safe as `BLAKE2B_DIGEST_LENGTH` is a valid value for a hasher
    let mut hasher = VarBlake2b::new(BLAKE2B_DIGEST_LENGTH).expect("should create hasher");

    hasher.update(data);
    hasher.finalize_variable(|slice| {
        result.copy_from_slice(slice);
    });
    result
}

pub fn get_stacking_contract_hash(builder: &WasmTestBuilder<InMemoryGlobalState>) -> ContractHash {
    let erc20_hash_addr = builder
        .get_expected_account(*DEFAULT_ACCOUNT_ADDR)
        .named_keys()
        .get(STAKING_CONTRACT_HASH)
        .expect("must have this entry in named keys")
        .into_hash()
        .expect("must get hash_addr");

    ContractHash::new(erc20_hash_addr)
}

pub(crate) fn get_erc20_contract_hash(
    builder: &WasmTestBuilder<InMemoryGlobalState>,
) -> ContractHash {
    let erc20_hash_addr = builder
        .get_expected_account(*DEFAULT_ACCOUNT_ADDR)
        .named_keys()
        .get(ERC20_CONTRACT_NAME)
        .expect("must have this entry in named keys")
        .into_hash()
        .expect("must get hash_addr");

    ContractHash::new(erc20_hash_addr)
}

fn balance_dictionary(
    builder: &WasmTestBuilder<InMemoryGlobalState>,
    erc20_contract_key: Key,
    owner_key: Key,
) -> U256 {
    let balance_seed_uref = builder
        .query(None, erc20_contract_key, &vec![])
        .unwrap()
        .as_contract()
        .expect("must have ERC20 contract")
        .named_keys()
        .get("balances")
        .expect("must have balances entry")
        .as_uref()
        .expect("must be a uref")
        .to_owned();

    let dict_item_key = make_dictionary_item_key(owner_key);

    let balance = builder
        .query_dictionary_item(None, balance_seed_uref, &dict_item_key)
        .expect("should be stored value.")
        .as_cl_value()
        .expect("should be cl value.")
        .clone()
        .into_t()
        .expect("must convert to U256");

    balance
}

fn allowance_dictionary(
    builder: &WasmTestBuilder<InMemoryGlobalState>,
    erc20_contract_key: Key,
    owner_key: Key,
    spender_key: Key,
) -> U256 {
    let allowance_seed_uref = builder
        .query(None, erc20_contract_key, &vec![])
        .unwrap()
        .as_contract()
        .expect("must have ERC20 contract")
        .named_keys()
        .get(ALLOWANCES_SEED_UREF)
        .expect("must have allowances entry")
        .as_uref()
        .expect("must be a uref")
        .to_owned();

    let dict_item_key = make_allowances_dictionary_item_key(owner_key, spender_key);

    let allowance = builder
        .query_dictionary_item(None, allowance_seed_uref, &dict_item_key)
        .expect("should be stored value.")
        .as_cl_value()
        .expect("should be cl value.")
        .clone()
        .into_t()
        .expect("must convert to U256");

    allowance
}

fn make_dictionary_item_key(owner: Key) -> String {
    let preimage = owner.to_bytes().unwrap();
    // NOTE: As for now dictionary item keys are limited to 64 characters only. Instead of using
    // hashing (which will effectively hash a hash) we'll use base64. Preimage is about 33 bytes for
    // both Address variants, and approximated base64-encoded length will be 4 * (33 / 3) ~ 44
    // characters.
    // Even if the preimage increased in size we still have extra space but even in case of much
    // larger preimage we can switch to base85 which has ratio of 4:5.
    base64::encode(&preimage)
}

// pub fn query<T: FromBytes + CLTyped>(
//     builder: &InMemoryWasmTestBuilder,
//     base: Key,
//     path: &[String],
// ) -> T {
//     builder
//         .query(None, base, path)
//         .expect("should be stored value.")
//         .as_cl_value()
//         .expect("should be cl value.")
//         .clone()
//         .into_t()
//         .expect("Wrong type in query result.")
// }

// #[test]
// fn test_stake() {
//     let (env, contract, owner) = deploy();
//     let user = env.next_user();

//     let res = contract.stake(owner, U256::from(1i64));
// }

// #[test]
// fn test_withdraw() {
//     let (env, contract, owner) = deploy();
//     let user = env.next_user();

//     // contract.stake(owner, U256::from(10i64));
//     contract.withdraw(owner, U256::from(1i64));
//     // assert_eq!(token.total_supply(), U256::from(1));
//     // assert_eq!(token.balance_of(Key::Account(user)), U256::from(1));
// }

// #[test]
// fn test_add_reward() {
//     let (env, contract, owner) = deploy();
//     let user = env.next_user();

//     contract.add_reward(owner, U256::from(1i64), U256::from(1i64));
//     // assert_eq!(token.total_supply(), U256::from(1));
//     // assert_eq!(token.balance_of(Key::Account(user)), U256::from(1));
// }
