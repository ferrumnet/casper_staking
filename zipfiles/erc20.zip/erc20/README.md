# casper-erc20

A library for developing ERC20 tokens for the Casper network.

To create an example ERC20 contract which uses this library, use the cargo-casper tool:

```
cargo install cargo-casper
cargo casper --erc20 <PATH TO NEW PROJECT>
```
